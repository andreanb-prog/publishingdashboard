'use client'
// app/(auth)/login/page.tsx
import { signIn } from 'next-auth/react'
import { useSearchParams } from 'next/navigation'

export default function LoginPage() {
  const searchParams = useSearchParams()
  const callbackUrl = searchParams.get('callbackUrl') || '/dashboard'

  return (
    <div className="min-h-screen bg-navy-DEFAULT flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-10">
          <h1 className="font-serif text-3xl text-white leading-tight mb-2">
            Publishing<br />
            <em className="not-italic text-amber-brand">Marketing</em> Dashboard
          </h1>
          <p className="text-sm text-white/40 mt-3">
            Your indie author marketing coach — powered by AI
          </p>
        </div>

        {/* Card */}
        <div className="bg-dk-surface border border-dk-surface2 rounded-2xl p-8">
          <h2 className="font-serif text-xl text-white mb-2">Welcome back</h2>
          <p className="text-sm text-dk-text3 mb-8 leading-relaxed">
            Sign in with your Google account to access your dashboard.
            Your data is private and only visible to you.
          </p>

          <button
            onClick={() => signIn('google', { callbackUrl })}
            className="w-full flex items-center justify-center gap-3 bg-white text-navy-DEFAULT
                       font-semibold py-3 px-6 rounded-xl hover:bg-cream transition-all
                       duration-150 text-sm"
          >
            <svg width="18" height="18" viewBox="0 0 18 18">
              <path fill="#4285F4" d="M16.51 8H8.98v3h4.3c-.18 1-.74 1.48-1.6 2.04v2.01h2.6a7.8 7.8 0 002.38-5.88c0-.57-.05-.66-.15-1.18z"/>
              <path fill="#34A853" d="M8.98 17c2.16 0 3.97-.72 5.3-1.94l-2.6-2a4.8 4.8 0 01-7.18-2.54H1.83v2.07A8 8 0 008.98 17z"/>
              <path fill="#FBBC05" d="M4.5 10.52a4.8 4.8 0 010-3.04V5.41H1.83a8 8 0 000 7.18l2.67-2.07z"/>
              <path fill="#EA4335" d="M8.98 4.18c1.17 0 2.23.4 3.06 1.2l2.3-2.3A8 8 0 001.83 5.4L4.5 7.49a4.77 4.77 0 014.48-3.3z"/>
            </svg>
            Continue with Google
          </button>

          <p className="text-xs text-dk-text3 text-center mt-6 leading-relaxed">
            By signing in, you agree to keep your API keys secure.
            We never share your data.
          </p>
        </div>

        {/* Bottom note */}
        <p className="text-center text-xs text-white/25 mt-8">
          Publishing Marketing Dashboard · Beta v0.1
        </p>
      </div>
    </div>
  )
}
